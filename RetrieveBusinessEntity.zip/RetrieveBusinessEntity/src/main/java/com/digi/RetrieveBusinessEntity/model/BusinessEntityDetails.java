package com.digi.RetrieveBusinessEntity.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BusinessEntityDetails {
    public String id;
    public String subRootId;
}
