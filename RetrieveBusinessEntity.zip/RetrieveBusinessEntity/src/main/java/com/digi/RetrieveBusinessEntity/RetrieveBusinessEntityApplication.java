package com.digi.RetrieveBusinessEntity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrieveBusinessEntityApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrieveBusinessEntityApplication.class, args);
	}

}
