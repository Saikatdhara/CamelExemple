package com.digi.RetrieveBusinessEntity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetrieveBusinessEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
