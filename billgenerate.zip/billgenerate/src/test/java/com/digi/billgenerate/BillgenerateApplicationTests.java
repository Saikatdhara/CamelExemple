package com.digi.billgenerate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillgenerateApplicationTests {

	@Test
	void contextLoads() {
	}

}
