package com.digi.billgenerate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillgenerateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillgenerateApplication.class, args);
	}

}
