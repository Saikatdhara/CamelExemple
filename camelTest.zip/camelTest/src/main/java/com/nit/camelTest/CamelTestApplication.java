package com.nit.camelTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelTestApplication.class, args);
	}

}
