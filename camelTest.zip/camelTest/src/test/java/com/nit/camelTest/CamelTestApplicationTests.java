package com.nit.camelTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
