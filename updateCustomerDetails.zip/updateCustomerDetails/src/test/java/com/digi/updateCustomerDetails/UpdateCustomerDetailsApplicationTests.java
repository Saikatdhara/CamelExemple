package com.digi.updateCustomerDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateCustomerDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
