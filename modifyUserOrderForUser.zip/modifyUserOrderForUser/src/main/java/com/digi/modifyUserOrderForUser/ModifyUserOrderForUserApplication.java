package com.digi.modifyUserOrderForUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModifyUserOrderForUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModifyUserOrderForUserApplication.class, args);
	}

}
