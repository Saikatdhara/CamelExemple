package com.example.demo.processor;

import com.example.demo.model.servicea.request.ServiceARequest;
import com.example.demo.model.serviceb.request.ServiceBRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class RequestProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        ServiceARequest serviceARequest = exchange.getIn().getBody(ServiceARequest.class);
        ServiceBRequest serviceBRequest = new ServiceBRequest();
        serviceBRequest.setMsisdn(serviceARequest.getBillingAccount().getId());
        serviceBRequest.setAccountNo(serviceARequest.getRelatedParty().getMsisdn());
        exchange.getIn().setBody(serviceBRequest);
    }
}
