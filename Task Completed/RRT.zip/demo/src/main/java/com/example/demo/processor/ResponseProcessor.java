package com.example.demo.processor;

import com.example.demo.model.servicea.response.BillingAccount;
import com.example.demo.model.servicea.response.CustomerBill;
import com.example.demo.model.servicea.response.RelatedParty;
import com.example.demo.model.servicea.response.ServiceAResponse;
import com.example.demo.model.serviceb.response.ServiceBResponse;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class ResponseProcessor implements Processor {
    @Override
    public void process(Exchange exchange) throws Exception {
        ServiceBResponse serviceBResponse = exchange.getIn().getBody(ServiceBResponse.class);

        ServiceAResponse serviceAResponse = new ServiceAResponse();
        BillingAccount billingAccount = new BillingAccount();
        CustomerBill customerBill = new CustomerBill();
        RelatedParty relatedParty = new RelatedParty();

        billingAccount.setId(serviceBResponse.getAccountNo());
        customerBill.setId(serviceBResponse.getBillNumber());
        relatedParty.setMsisdn(serviceBResponse.getMsisdn());

        serviceAResponse.setBillingAccount(billingAccount);
        serviceAResponse.setCustomerBill(customerBill);
        serviceAResponse.setRelatedParty(relatedParty);
        exchange.getIn().setBody(serviceAResponse);
    }
}
